/*******************************************************************************
 * Copyright (c) 2011, 2012 Syntevo GmbH and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Syntevo GmbH - initial API and implementation
 *******************************************************************************/
package com.syntevo.q.swt;

import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.widgets.*;

/**
 * @author syntevo GmbH
 */
public interface QControlContentAdapter {

	Control getControl();

	String getText();

	void setText(String contents);

	void insert(String contents);

	int getCaretPosition();

	Rectangle getInsertionBounds();

	boolean hasSelection();

	void setSelection(int start, int end);

	void addModifyListener(ModifyListener listener);
}
