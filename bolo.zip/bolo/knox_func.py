#   Originally in matlab by J.Ruhl, converted to Python by S.Wen Nov. 2014
#   Evaluate knox-formula estimates for a given experiment.
#   returns the covariances for C_l bins.
planck150={'title': 'Planck, 150GHz, 1 year',
        'freq' : 150,
        'ndet' : 8,           # this is the number of polarization sensitive bolos;  4 more unpol.
        'net': 62,  # per detector at 150GHz
        'days': 365*(14/12),  # 14 months, to match bluebook,
        'fwhm': 7.1,          # from bluebook
        'sqdeg': 0.8*42000,
        'deltaell': 10,
        'lowestell': 2,
        }
        
# Planck 90GHz is similar:  NET = 50, Ndet=8, 9.5arcmin beams.
planck90={'title': 'Planck, 90GHz, 1 year',
        'freq' : 90,
        'ndet' : 8,           # this is the number of polarization sensitive bolos;  4 more unpol.
        'net': 50,  # per detector at 150GHz
        'days': 365*(14/12),  # 14 months, to match bluebook,
        'fwhm': 9.5,          # from bluebook
        'sqdeg': 0.8*42000,
        'deltaell': 10,
        'lowestell': 2,
        }

# spider, 3 telescopes at 150GHz, McMurdo
spider={'title': 'Spider, 3 telescopes, 1 McMurdo flight',
        'freq' : 150,   #GHz
        'net': 150,  # uKrtsec_cmb
        'days': 20,  #days in an LDB flight
        'fwhm': 30,  #arcmin   
        'ndet': 3*(4*2*64), # 3 telescopes
        'sqdeg': 3000,  #sky area coverage
        'deltaell': 20,
        'topbin': 500,
        'lowestell': 50,
        }

# keck at 3 telescopes, 1 year
keck1={'title': 'Keck, 1 year, 3 telescopes',
       'freq' : 150,
        'net': 450,  # per detector at 150GHz
        'days': 0.3*3*365,
        'fwhm': 30,
        'ndet': 3*4*2*64, 
        'sqdeg': 1000,
        'deltaell': 25,
        'topbin': 500,
        'lowestell': 50,
        }
# keck at 3 years
keck3 = keck1;
keck3={'title': 'Keck, 3 years, 3 telescopes'}

# sptsz
sptsz={'title': 'SPT-SZ, 3 years, 2000sqdeg',
       'freq' : 150,
        'net': 350,  # per detector at 150GHz
        'days': 0.3*3*365,
        'fwhm': 1,
        'ndet': 650, 
        'sqdeg': 2000,
        'deltaell': 200,
        'topbin': 4000,
        'dl' : 50,
        'lowestell': 600,
        }
        
# sptpol
sptpol = sptsz;
sptpol={'title': 'SPTpol 150GHz, 30 sq deg, 3 years',
        'net': 448/2,  # per detector at 150GHz
     #   'net': 394,  # per detector at 90GHz
        'days': 0.25*3*365,
        'fwhm': 1,
        'ndet': (7*84)*2, # at 150GHz
        'sqdeg': 30.0,
        'deltaell': 100,
        'topbin': 4000,
        'lowestell': 50,
        }

# sptpol2011
sptpol2011 = sptpol;
sptpol2011={'title': 'SPTpol2011',
        'net': 394,  
        'days': 0.25*3*365,
        'fwhm': 1.6,
        'ndet': 2*192, # 90's only
        'sqdeg': 100,
        'deltaell': 100,
        'lowestell': 50,
        }
        
# sptpol2
sptpol2 = sptpol;
sptpol2={'title': 'SPTpol2',
        'net': 300,  # per detector at 150GHz
        'ndet': 2*sptpol['ndet'],
        'sqdeg': 2000,
        'deltaell': 50,
        'lowestell': 50,
        }
        
# Polar1
polar1={'title': 'Polar 1, 1000sqdeg',
        'net': 350,  
        'days': 0.3*3*365,
        'fwhm': 5,
        'ndet': 2000, 
        'sqdeg': 1000,
        'deltaell': 50,
        'lowestell': 50,
        }
       
# Polar10
polar10 = polar1;
polar10={'title': 'Polar10, 2000sqdeg',
        'days': 10*polar1['days'],
        'sqdeg': 2000,
        }
        
import numpy
def knox_func(expt=None,baseCls=None):
    SecPerDay=24 * 60 * 60
    ell=(baseCls[:,0]).astype(int)
    factor=ell*((ell + 1)) / (2 *numpy.pi)
    C_TT=baseCls[:,1] / factor
    C_EE=baseCls[:,2] / factor
    C_BB=baseCls[:,3] / factor
    C_TE=baseCls[:,4] / factor

#  create binned spectra
#  binX is the index
    lastbinstart=min(expt['topbin'],ell[-1] - 1 - expt['deltaell'])
    binstarts=numpy.arange(expt['lowestell'] - 1,lastbinstart+1,expt['deltaell'])  #this is an indexer
    binends = binstarts+expt['deltaell']-1

    l_b=numpy.zeros((len(binstarts),1))
    C_TT_b=numpy.zeros((len(binstarts),1))
    C_EE_b=numpy.zeros((len(binstarts),1))
    C_BB_b=numpy.zeros((len(binstarts),1))
    C_TE_b=numpy.zeros((len(binstarts),1))

    for ii in range(len(binstarts)):
        l_b[ii,0]=numpy.mean(ell[binstarts[ii]-1:binends[ii]])
        C_TT_b[ii,0]=numpy.mean(C_TT[binstarts[ii]-1:binends[ii]])
        C_EE_b[ii,0]=numpy.mean(C_EE[binstarts[ii]-1:binends[ii]])
        C_BB_b[ii,0]=numpy.mean(C_BB[binstarts[ii]-1:binends[ii]])
        C_TE_b[ii,0]=numpy.mean(C_TE[binstarts[ii]-1:binends[ii]])
    
    Cls=numpy.concatenate((l_b,C_TT_b,C_EE_b,C_BB_b,C_TE_b),1)

    fullsky=41253 #square degrees
    
    fsky=expt['sqdeg'] / fullsky
    sigma_beam=(expt['fwhm']/ (numpy.sqrt(8 * numpy.log(2)))) * (1 / 60) * (numpy.pi / 180)
    sigb2=sigma_beam ** 2
    sig2_T=(expt['net'] / numpy.sqrt(expt['ndet'] * expt['days'] * SecPerDay)) ** 2
    sig2_P=2 * sig2_T  #in K^2

    #Calculate the weights per unit solid angle
    w_T=(1 / sig2_T) / (fsky * 4 * numpy.pi)  #1/(K^2 rad^2);
    w_P=(1 / sig2_P) / (fsky * 4 * numpy.pi)
    inv_w_T=1 / w_T
    inv_w_P=1 / w_P

    A=1.0 / (fsky * (2.0 * l_b + 1) * expt['deltaell'])
    wB_T=inv_w_T * numpy.exp((l_b*l_b) * sigb2)    #weight times beam factor
    wB_P=inv_w_P * numpy.exp((l_b*l_b) * sigb2)

    cov_TT=2 * A*((C_TT_b + wB_T) ** 2)
    cov_EE=2 * A*((C_EE_b + wB_P) ** 2)
    cov_BB=2 * A*((C_BB_b + wB_P) ** 2)
    #cov_cosvar = 2*A.*C_TT_b.^2;
    #cov_noise =  2*A.*wB_T_b.^2;
    
    cov_TE=A*((C_TE_b ** 2 + (C_TT_b + wB_T)*((C_EE_b + wB_P))))
    cov_Cls=numpy.concatenate((l_b,cov_TT,cov_EE,cov_BB,cov_TE),1)

    data={'Cls':Cls,'cov_Cls':cov_Cls}
    return data
